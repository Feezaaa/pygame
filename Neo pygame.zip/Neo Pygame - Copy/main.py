import pygame, sys
from pygame.math import Vector2
from os import walk

# screen settings
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
TILE_SIZE = 64

# overlay positions 
OVERLAY_POSITIONS = {
	'tool' : (40, SCREEN_HEIGHT - 15), 
	'seed': (70, SCREEN_HEIGHT - 5)}

PLAYER_TOOL_OFFSET = {
	'left': Vector2(-50,40),
	'right': Vector2(50,40),
	'up': Vector2(0,-10),
	'down': Vector2(0,50)
}

LAYERS = {
	'water': 0,
	'ground': 1,
	'soil': 2,
	'soil water': 3,
	'rain floor': 4,
	'house bottom': 5,
	'ground plant': 6,
	'main': 7,
	'house top': 8,
	'fruit': 9,
	'rain drops': 10
}

APPLE_POS = {
	'Small': [(18,17), (30,37), (12,50), (30,45), (20,30), (30,10)],
	'Large': [(30,24), (60,65), (50,50), (16,40),(45,50), (42,70)]
}

GROW_SPEED = {
	'corn': 1,
	'tomato': 0.7
}

SALE_PRICES = {
	'wood': 4,
	'apple': 2,
	'corn': 10,
	'tomato': 20
}

PURCHASE_PRICES = {
	'corn': 4,
	'tomato': 5
}

def import_folder(path):
	surface_list = []
	for _, __, img_files in walk(path):
		for image in img_files:
			full_path = path + '/' + image
			image_surf = pygame.image.load(full_path).convert_alpha()
			surface_list.append(image_surf)
	return surface_list

# Initialize pygame and create window
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
pygame.display.set_caption('Sprout land')
clock = pygame.time.Clock()

# Initialize sprite groups
all_sprites = pygame.sprite.Group()

# Player setup
player_animations = {'up': [],'down': [],'left': [],'right': [],
				   'right_idle':[],'left_idle':[],'up_idle':[],'down_idle':[],
				   'right_hoe':[],'left_hoe':[],'up_hoe':[],'down_hoe':[],
				   'right_axe':[],'left_axe':[],'up_axe':[],'down_axe':[],
				   'right_water':[],'left_water':[],'up_water':[],'down_water':[]}

for animation in player_animations.keys():
	full_path = '../graphics/character/' + animation
	player_animations[animation] = import_folder(full_path)

player_status = 'down_idle'
player_frame_index = 0
player_pos = pygame.math.Vector2(640, 360)
player_direction = pygame.math.Vector2()
player_speed = 200

# Create player sprite
player = pygame.sprite.Sprite()
player.image = player_animations[player_status][int(player_frame_index)]
player.rect = player.image.get_rect(center = player_pos)
all_sprites.add(player)

def player_animate(dt):
	global player_frame_index
	player_frame_index += 4 * dt
	if player_frame_index >= len(player_animations[player_status]):
		player_frame_index = 0
	player.image = player_animations[player_status][int(player_frame_index)]

def player_input():
	global player_status, player_direction
	keys = pygame.key.get_pressed()

	if keys[pygame.K_UP]:
		player_direction.y = -1
		player_status = 'up'
	elif keys[pygame.K_DOWN]:
		player_direction.y = 1
		player_status = 'down'
	else:
		player_direction.y = 0

	if keys[pygame.K_RIGHT]:
		player_direction.x = 1
		player_status = 'right'
	elif keys[pygame.K_LEFT]:
		player_direction.x = -1
		player_status = 'left'
	else:
		player_direction.x = 0

def get_player_status():
	global player_status
	if player_direction.magnitude() == 0:
		player_status = player_status.split('_')[0] + '_idle'

def player_move(dt):
	global player_pos
	if player_direction.magnitude() > 0:
		player_direction.normalize_ip()

	player_pos.x += player_direction.x * player_speed * dt
	player.rect.centerx = player_pos.x

	player_pos.y += player_direction.y * player_speed * dt 
	player.rect.centery = player_pos.y

# Game loop
while True:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			pygame.quit()
			sys.exit()

	dt = clock.tick() / 1000
	
	# Update
	player_input()
	get_player_status()
	player_move(dt)
	
	# Ensure frame index is valid before animating
	if player_frame_index < len(player_animations[player_status]):
		player_animate(dt)
	else:
		player_frame_index = 0
	
	# Draw
	screen.fill('black')
	all_sprites.draw(screen)
	pygame.display.update()